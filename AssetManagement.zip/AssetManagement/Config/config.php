<?php

return [
    'name' => 'AssetManagement',
    'module_version' => '3.0',
    'pid' => 14,
];
