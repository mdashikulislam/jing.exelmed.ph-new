<?php

return [
    'name' => 'Superadmin',
    'module_version' => '6.4',
    'pid' => 20
];
